package bignumber;

public class Node {
  int value;
  Node next;
  Node pre;

  public Node(){
    this.value= 0;
    this.next=null;
    this.pre=null;
  }
}
