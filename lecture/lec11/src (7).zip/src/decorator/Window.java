package decorator;

public interface Window {
    public void draw();
}
