package adaptor;

public interface ReverseIterator {
    boolean hasPrev();
    int prev();
}
