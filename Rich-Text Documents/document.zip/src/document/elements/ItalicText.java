package document.elements;

/**
 * Representation for italic text.
 */
public class ItalicText extends BasicText {
  
  public ItalicText(String text) {
    super(text);
  }
}
