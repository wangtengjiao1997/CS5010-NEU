public class Order {
    public Order(int a) {amount = a;}
    int amount;
}
