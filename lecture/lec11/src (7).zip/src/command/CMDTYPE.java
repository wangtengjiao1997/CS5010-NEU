package command;

public enum CMDTYPE {
    JUMP,
    MOVE,
    SHOOT
}
