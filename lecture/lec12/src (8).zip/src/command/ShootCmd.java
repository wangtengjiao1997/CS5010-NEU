package command;

public class ShootCmd implements Command {
    @Override
    public void exec() {
        // 1000 loc
        System.out.println("shoot");
    }
}
