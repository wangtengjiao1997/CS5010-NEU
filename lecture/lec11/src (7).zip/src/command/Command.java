package command;
public interface Command {
    void exec();
}
