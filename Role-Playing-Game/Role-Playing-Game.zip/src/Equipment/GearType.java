package Equipment;

/**
 * This enum class is storing the three types of the equipments
 */
public enum GearType {
  FOOT_WEAR,
  HEAD_GEAR,
  HAND_GEAR
}
