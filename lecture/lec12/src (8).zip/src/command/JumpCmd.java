package command;

public class JumpCmd implements Command {
    @Override
    public void exec() {
        // 1000 loc
        System.out.println("jump");
    }
}
