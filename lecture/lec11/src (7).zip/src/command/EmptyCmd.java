package command;

public class EmptyCmd implements Command {
    @Override
    public void exec() {
        // do nothing
    }
}
