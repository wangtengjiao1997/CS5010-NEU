package document;

import java.util.ArrayList;
import java.util.List;

import document.elements.TextElement;

public class Document {
  
  private List<TextElement> content;
  
  public Document() {
    content = new ArrayList<>();
  }

  public void add(TextElement e) {
    content.add(e);
  }
}
